<?php


        interface emitir{
            public function emitir();
        

        }